package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import com.nik.visuals.client.slot.CooldownQuery;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class CooldownHudRenderer {
    private float appear;
    private int lastX, lastY, lastW, lastH;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }

    private static class Row {
        final ItemStack stack;
        final String name;
        final int seconds;
        Row(ItemStack s, String n, int sec) { stack = s; name = n; seconds = sec; }
    }

    public void render(DrawContext g, float pt) {
        if (!ModConfig.cooldownHud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options.hudHidden) return;

        // name -> best remaining seconds (dedupe)
        Map<String, Row> map = new LinkedHashMap<>();
        for (int i = 0; i < 36; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isEmpty()) continue;
            int sec = CooldownQuery.remainingSeconds(p, st, pt);
            if (sec < 1) continue;

            String name = st.getName().getString().replaceAll("§.", "");
            if (name.length() > 18) name = name.substring(0, 17) + "…";
            Row prev = map.get(name);
            if (prev == null || sec > prev.seconds) {
                map.put(name, new Row(st.copy(), name, sec));
            }
        }

        List<Row> rows = new ArrayList<>(map.values());
        boolean show = !rows.isEmpty() || ModConfig.layoutEdit;
        appear = Anim.approach(appear, show ? 1f : 0f, 0.15f);
        if (appear < 0.02f) return;

        float a = Anim.easeOutCubic(appear);
        int x = (int) (ModConfig.cooldownHudX * mc.getWindow().getScaledWidth());
        int y = (int) (ModConfig.cooldownHudY * mc.getWindow().getScaledHeight());

        if (rows.isEmpty() && ModConfig.layoutEdit) {
            lastX = x; lastY = y; lastW = 120; lastH = 28;
            GuiDraw.glassPanel(g, x, y, 120, 28, 10, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));
            g.drawText(mc.textRenderer, "Кулдауны", x + 12, y + 10, Style.alpha(Style.TEXT_DIM, a), false);
            return;
        }
        if (rows.isEmpty()) return;

        int lineH = 18;
        int w = 130;
        for (Row r : rows) {
            w = Math.max(w, 28 + mc.textRenderer.getWidth(r.name) + 36);
        }
        int h = 8 + rows.size() * lineH;
        lastX = x; lastY = y; lastW = w; lastH = h;

        int drawX = x + (int) ((1f - a) * -8);
        GuiDraw.glassPanel(g, drawX, y, w, h, 10, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));

        int row = 0;
        for (Row r : rows) {
            int ry = y + 5 + row * lineH;
            GuiDraw.fillRounded(g, drawX + 4, ry, 14, 14, 4, Style.alpha(Style.GLASS, a));
            g.drawItem(r.stack, drawX + 5, ry);
            g.drawText(mc.textRenderer, r.name, drawX + 22, ry + 3, Style.alpha(Style.TEXT, a), false);
            String t = r.seconds + "с";
            int tw = mc.textRenderer.getWidth(t);
            g.drawText(mc.textRenderer, t, drawX + w - 8 - tw, ry + 3, Style.alpha(Style.ACCENT, a), false);
            row++;
        }
    }

    private int guessTotalTicks(ItemStack st) {
        String n = st.getName().getString().toLowerCase();
        // Funtime-ish common
        if (n.contains("трап") || n.contains("trap")) return 40;   // ~2s shown as 2c in screenshot wrong before
        if (n.contains("пласт") || n.contains("plast")) return 120;
        if (n.contains("жемчуг") || n.contains("pearl")) return 20;
        if (n.contains("хор") || n.contains("chorus")) return 20;
        if (n.contains("яблок") || n.contains("apple")) return 20;
        // default 60 ticks = 3s period -> progress maps better for mid cooldowns
        return 60;
    }
}
