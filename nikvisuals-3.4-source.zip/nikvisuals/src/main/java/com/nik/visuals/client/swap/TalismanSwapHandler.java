package com.nik.visuals.client.swap;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.GuiDraw;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class TalismanSwapHandler {
    private static final String[] ALLOWED = {
            "талисман крушителя", "талисман карателя", "талисман раздора", "талисман тирана",
            "талисман ярости", "талисман вихря", "талисман мрака", "талисман демона",
            "сфера афины", "сфера титана", "сфера хаоса", "сфера сатира", "сфера бестии",
            "сфера ареса", "сфера гидры", "сфера икара", "сфера эрида"
    };

    private static final long SWAP_COOLDOWN_MS = 350L; // short
    private long lastSwapMs;
    private boolean wasDown;
    private int hovered = -1;
    private final List<Candidate> candidates = new ArrayList<>();
    private float openAnim;
    private float spin;
    private String statusMsg;
    private long statusUntil;
    private int freezeTicks;

    public void tick(MinecraftClient mc, boolean keyDown) {
        if (freezeTicks > 0) {
            freezeTicks--;
            stopMovement(mc);
        }

        if (!ModConfig.talismanSwap || mc.player == null || mc.currentScreen != null) {
            wasDown = false;
            candidates.clear();
            hovered = -1;
            openAnim = Math.max(0f, openAnim - 0.2f);
            return;
        }

        if (keyDown) {
            if (!wasDown) {
                rebuildCandidates(mc.player);
                hovered = candidates.isEmpty() ? -1 : 0;
            }
            updateHover(mc);
            openAnim = Math.min(1f, openAnim + 0.18f);
            spin += 0.04f;
            stopMovement(mc);
            wasDown = true;
        } else {
            if (wasDown && hovered >= 0 && hovered < candidates.size()) {
                trySwap(mc, candidates.get(hovered));
            }
            wasDown = false;
            candidates.clear();
            hovered = -1;
            openAnim = Math.max(0f, openAnim - 0.22f);
        }
    }

    private void stopMovement(MinecraftClient mc) {
        try {
            if (mc.player == null || mc.options == null) return;
            mc.options.forwardKey.setPressed(false);
            mc.options.backKey.setPressed(false);
            mc.options.leftKey.setPressed(false);
            mc.options.rightKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            mc.options.sprintKey.setPressed(false);
            mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
        } catch (Throwable ignored) {}
    }

    private void trySwap(MinecraftClient mc, Candidate c) {
        long now = System.currentTimeMillis();
        if (now - lastSwapMs < SWAP_COOLDOWN_MS) {
            statusMsg = "§cПодожди…";
            statusUntil = now + 500;
            return;
        }
        stopMovement(mc);
        // ONE method only: clickSlot SWAP with offhand (button 40)
        if (swapOffhandOnce(mc, c)) {
            lastSwapMs = now;
            freezeTicks = 3;
            statusMsg = "§a" + c.displayName;
            statusUntil = now + 800;
        } else {
            statusMsg = "§cНе вышло";
            statusUntil = now + 600;
        }
    }

    /** Single inventory click — no hotbar switch packets (less AC flags). */
    private boolean swapOffhandOnce(MinecraftClient mc, Candidate c) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;
        try {
            ItemStack cur = p.getInventory().getStack(c.invSlot);
            if (cur.isEmpty() || !isAllowed(cur)) return false;
            if (ItemStack.areItemsAndComponentsEqual(p.getOffHandStack(), cur)) return true;

            int syncId = p.currentScreenHandler != null ? p.currentScreenHandler.syncId : p.playerScreenHandler.syncId;
            // Player inventory container slots: 9-35 main, 36-44 hotbar in survival inventory screen.
            // When no screen open, interactionManager still accepts playerScreenHandler.
            int containerSlot;
            if (c.invSlot < 9) {
                containerSlot = 36 + c.invSlot; // hotbar
            } else {
                containerSlot = c.invSlot; // 9..35
            }
            mc.interactionManager.clickSlot(syncId, containerSlot, 40, SlotActionType.SWAP, p);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private void rebuildCandidates(ClientPlayerEntity player) {
        candidates.clear();
        // one entry per display name
        Map<String, Candidate> uniq = new LinkedHashMap<>();
        for (int i = 0; i < 36; i++) {
            ItemStack st = player.getInventory().getStack(i);
            if (st.isEmpty() || !isAllowed(st)) continue;
            String key = normalize(st.getName().getString());
            if (uniq.containsKey(key)) continue; // keep first only
            uniq.put(key, new Candidate(i, st.copy(), st.getName().getString().replaceAll("§.", "")));
        }
        candidates.addAll(uniq.values());
    }

    public static boolean isAllowed(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        String name = normalize(stack.getName().getString());
        for (String a : ALLOWED) {
            if (name.equals(a) || name.contains(a)) return true;
        }
        return false;
    }

    private static String normalize(String s) {
        return s.replaceAll("§.", "").toLowerCase(Locale.ROOT).trim();
    }

    private void updateHover(MinecraftClient mc) {
        if (candidates.isEmpty()) {
            hovered = -1;
            return;
        }
        double mx = mc.mouse.getX() * mc.getWindow().getScaledWidth() / Math.max(1, mc.getWindow().getWidth());
        double my = mc.mouse.getY() * mc.getWindow().getScaledHeight() / Math.max(1, mc.getWindow().getHeight());
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        double dx = mx - cx;
        double dy = my - cy;
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 26) return;
        double ang = Math.atan2(dy, dx);
        if (ang < 0) ang += Math.PI * 2;
        int n = candidates.size();
        hovered = (int) (ang / (Math.PI * 2 / n)) % n;
    }

    public void render(DrawContext g, float pt) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        long now = System.currentTimeMillis();
        if (statusMsg != null && now < statusUntil) {
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            g.drawCenteredTextWithShadow(mc.textRenderer, statusMsg, sw / 2, sh / 2 + 72, 0xFFFFFFFF);
        }

        if (openAnim < 0.02f || candidates.isEmpty()) return;

        float a = openAnim;
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        int n = candidates.size();
        double radius = 74 + 5 * Math.sin(spin * 2);

        drawRing(g, cx, cy, (int) radius + 20, 18, Style.alpha(0xFF101010, a * 0.92f));
        drawRing(g, cx, cy, (int) radius + 20, 2, Style.alpha(Style.ACCENT, a * 0.7f));

        GuiDraw.fillSoftCircle(g, cx, cy, 24, Style.alpha(Style.PANEL, a));
        GuiDraw.fillSoftCircle(g, cx, cy, 22, Style.alpha(0xFF0A0A0A, a));
        String tip = hovered >= 0 && hovered < n ? candidates.get(hovered).displayName : "Выбор";
        if (tip.length() > 18) tip = tip.substring(0, 17) + "…";
        g.drawCenteredTextWithShadow(mc.textRenderer, tip, cx, cy - 4, Style.alpha(Style.TEXT, a));
        g.drawCenteredTextWithShadow(mc.textRenderer, "отпусти", cx, cy + 8, Style.alpha(Style.TEXT_DIM, a));

        for (int i = 0; i < n; i++) {
            double ang = -Math.PI / 2 + (Math.PI * 2 * i / n);
            int ix = cx + (int) (Math.cos(ang) * radius);
            int iy = cy + (int) (Math.sin(ang) * radius);
            boolean hot = i == hovered;
            int size = hot ? 18 : 14;
            GuiDraw.fillSoftCircle(g, ix, iy, size + 5,
                    Style.alpha(hot ? Style.ACCENT : 0xFF1C1C1C, a * (hot ? 0.9f : 0.6f)));
            GuiDraw.fillSoftCircle(g, ix, iy, size + 1, Style.alpha(Style.PANEL, a));
            g.drawItem(candidates.get(i).stack, ix - 8, iy - 8);
            if (hot) {
                for (int p = 0; p < 6; p++) {
                    double pa = spin * 3 + p * (Math.PI * 2 / 6.0);
                    int px = ix + (int) (Math.cos(pa) * (size + 7));
                    int py = iy + (int) (Math.sin(pa) * (size + 7));
                    GuiDraw.fillSoftCircle(g, px, py, 1, Style.alpha(Style.ACCENT, a * 0.75f));
                }
            }
        }
    }

    private void drawRing(DrawContext g, int cx, int cy, int r, int thick, int color) {
        int steps = 52;
        for (int i = 0; i < steps; i++) {
            double a0 = (Math.PI * 2 * i) / steps;
            double a1 = (Math.PI * 2 * (i + 1)) / steps;
            for (int t = 0; t < thick; t++) {
                int rr = r - t;
                int x0 = cx + (int) (Math.cos(a0) * rr);
                int y0 = cy + (int) (Math.sin(a0) * rr);
                int x1 = cx + (int) (Math.cos(a1) * rr);
                int y1 = cy + (int) (Math.sin(a1) * rr);
                g.fill(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1) + 1, Math.max(y0, y1) + 1, color);
            }
        }
    }

    private static final class Candidate {
        final int invSlot;
        final ItemStack stack;
        final String displayName;
        Candidate(int invSlot, ItemStack stack, String displayName) {
            this.invSlot = invSlot;
            this.stack = stack;
            this.displayName = displayName;
        }
    }
}
