package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class ColorFilterRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.colorFilter) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null) {
            return;
        }
        float intensity = Math.max(0.05f, Math.min(0.7f, ModConfig.filterIntensity));
        int a = (int)(intensity * 180.0f);
        int rgb = ModConfig.filterColor & 0xFFFFFF;
        int color = a << 24 | rgb;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        g.fill(0, 0, sw, sh, color);
    }
}

