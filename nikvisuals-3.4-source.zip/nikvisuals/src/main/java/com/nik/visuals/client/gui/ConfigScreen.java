package com.nik.visuals.client.gui;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.GuiDraw;
import com.nik.visuals.client.render.InventoryHudRenderer;
import com.nik.visuals.client.render.PotionsRenderer;
import com.nik.visuals.client.render.TargetHUD;
import com.nik.visuals.client.render.WatermarkRenderer;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class ConfigScreen extends Screen {
    private final Screen parent;
    private final TargetHUD targetHUD;
    private final PotionsRenderer potionsRenderer;
    private final WatermarkRenderer watermarkRenderer;
    private final InventoryHudRenderer inventoryHud;

    private enum Cat { VISUALS, HUD, UTILS }
    private Cat cat = Cat.VISUALS;
    private final List<Row> all = new ArrayList<>();
    private final List<Row> view = new ArrayList<>();
    private String search = "";
    private boolean searchFocus;
    private int scroll;
    private float openA;
    private float[] knob = new float[80];
    private float particleT;
    private boolean[] collapsed = new boolean[3];

    private static final int W = 320, H = 240;
    private static final int SIDE = 78;
    private static final int ROW = 18;

    public ConfigScreen(Screen parent, TargetHUD th, PotionsRenderer pr, WatermarkRenderer wm, InventoryHudRenderer inv) {
        super(Text.literal("Nik Visuals"));
        this.parent = parent;
        this.targetHUD = th;
        this.potionsRenderer = pr;
        this.watermarkRenderer = wm;
        this.inventoryHud = inv;
        build();
        filter();
        particleT = 1f;
    }

    private void add(Cat c, String name, String[] keys, Supplier<Boolean> g, Consumer<Boolean> s) {
        all.add(new Row(c, name, keys, g, s));
    }

    private void build() {
        all.clear();
        add(Cat.VISUALS, "Траектория", new String[]{"trajectory", "траектория"}, () -> ModConfig.trajectory, v -> ModConfig.trajectory = v);
        add(Cat.VISUALS, "Обводка блоков", new String[]{"outline", "обводка"}, () -> ModConfig.blockOutline, v -> ModConfig.blockOutline = v);
        add(Cat.VISUALS, "Пульс урона", new String[]{"pulse", "урон"}, () -> ModConfig.damagePulse, v -> ModConfig.damagePulse = v);
        add(Cat.VISUALS, "Пульс низкого ХП", new String[]{"low", "хп"}, () -> ModConfig.lowHealthPulse, v -> ModConfig.lowHealthPulse = v);
        add(Cat.VISUALS, "Ambience", new String[]{"ambience"}, () -> ModConfig.ambience, v -> ModConfig.ambience = v);
                add(Cat.HUD, "Target HUD", new String[]{"target", "таргет"}, () -> ModConfig.targetHud, v -> ModConfig.targetHud = v);
        add(Cat.HUD, "Частицы на цели", new String[]{"particle", "частиц"}, () -> ModConfig.targetParticles, v -> ModConfig.targetParticles = v);
        add(Cat.HUD, "HUD кулдаунов", new String[]{"cooldown", "кд", "кулдаун"}, () -> ModConfig.cooldownHud, v -> ModConfig.cooldownHud = v);
        add(Cat.HUD, "Зелья", new String[]{"potion", "зелье"}, () -> ModConfig.potions, v -> ModConfig.potions = v);
        add(Cat.HUD, "Ватермарка", new String[]{"watermark", "fps", "ping"}, () -> ModConfig.watermark, v -> ModConfig.watermark = v);
        add(Cat.HUD, "Кулдаун слотов", new String[]{"slot", "кд", "cooldown"}, () -> ModConfig.slotTimer, v -> ModConfig.slotTimer = v);
        add(Cat.HUD, "Сытость", new String[]{"hunger", "сытость"}, () -> ModConfig.saturationHud, v -> ModConfig.saturationHud = v);
        add(Cat.HUD, "Броня HUD", new String[]{"armor", "броня"}, () -> ModConfig.armorHud, v -> ModConfig.armorHud = v);
        add(Cat.HUD, "Инвентарь", new String[]{"inventory", "инвентарь"}, () -> ModConfig.inventoryHud, v -> ModConfig.inventoryHud = v);
        add(Cat.HUD, "Дистанция", new String[]{"distance", "дистанция"}, () -> ModConfig.showDistance, v -> ModConfig.showDistance = v);
        add(Cat.HUD, "Броня в таргете", new String[]{"show armor"}, () -> ModConfig.showArmor, v -> ModConfig.showArmor = v);
        add(Cat.UTILS, "Full Bright", new String[]{"fullbright", "свет"}, () -> ModConfig.fullbright, v -> ModConfig.fullbright = v);
        add(Cat.UTILS, "Без эффектов", new String[]{"clear", "эффекты"}, () -> ModConfig.clearEffects, v -> ModConfig.clearEffects = v);
        add(Cat.UTILS, "Оптимизация PvP", new String[]{"optimize", "оптим"}, () -> ModConfig.optimizePvp, v -> ModConfig.optimizePvp = v);
        add(Cat.UTILS, "Свап талисманов", new String[]{"swap", "талисман"}, () -> ModConfig.talismanSwap, v -> ModConfig.talismanSwap = v);
        add(Cat.UTILS, "Звуки UI", new String[]{"sound", "звук"}, () -> ModConfig.uiSounds, v -> ModConfig.uiSounds = v);
        add(Cat.UTILS, "Координаты", new String[]{"coords", "координаты"}, () -> ModConfig.showCoords, v -> ModConfig.showCoords = v);
        add(Cat.UTILS, "Предупр. брони", new String[]{"armor warn"}, () -> ModConfig.armorWarn, v -> ModConfig.armorWarn = v);
    }

    private void filter() {
        view.clear();
        String q = search.toLowerCase(Locale.ROOT).trim();
        for (Row r : all) {
            if (!q.isEmpty()) {
                if (r.matches(q)) view.add(r);
            } else if (r.cat == cat) {
                view.add(r);
            }
        }
        scroll = 0;
    }

    private void clickSound() {
        if (!ModConfig.uiSounds) return;
        try {
            MinecraftClient.getInstance().getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(), 1.15f, 0.25f));
        } catch (Throwable ignored) {}
    }

    @Override
    public void tick() {
        openA = Anim.approach(openA, 1f, 0.2f);
        particleT = Anim.approach(particleT, 0f, 0.04f);
        for (int i = 0; i < view.size() && i < knob.length; i++) {
            knob[i] = Anim.approach(knob[i], view.get(i).get.get() ? 1f : 0f, 0.28f);
        }
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        float a = Anim.easeOutCubic(openA);
        int x = width / 2 - W / 2;
        int y = height / 2 - H / 2 + (int) ((1f - a) * 16);

        g.fill(0, 0, width, height, Style.solidAlpha(0x000000, (int) (140 * a)));

        // soft particles on open
        if (particleT > 0.05f) {
            int n = 12;
            for (int i = 0; i < n; i++) {
                float t = particleT;
                int px = x + 40 + (i * 23) % (W - 20);
                int py = y + 30 + (int) ((1f - t) * (20 + i * 3));
                int al = (int) (80 * t);
                g.fill(px, py, px + 2, py + 2, Style.solidAlpha(0x3DCC7A, al));
            }
        }

        GuiDraw.glassPanel(g, x, y, W, H, 10, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));
        g.fill(x, y, x + 3, y + H, Style.alpha(Style.ACCENT, a));

        // sidebar
        g.fill(x + 3, y, x + SIDE, y + H, Style.alpha(Style.BG_DEEP, a * 0.9f));
        g.drawText(textRenderer, "NV", x + 14, y + 12, Style.alpha(Style.ACCENT, a), false);
        g.drawText(textRenderer, "§83.1", x + 34, y + 12, Style.alpha(Style.TEXT_DIM, a), false);

        drawSideBtn(g, x + 8, y + 36, "Визуалы", cat == Cat.VISUALS, mx, my, a);
        drawSideBtn(g, x + 8, y + 54, "HUD", cat == Cat.HUD, mx, my, a);
        drawSideBtn(g, x + 8, y + 72, "Утилиты", cat == Cat.UTILS, mx, my, a);

        // presets
        g.drawText(textRenderer, "Пресет", x + 10, y + H - 52, Style.alpha(Style.TEXT_DIM, a), false);
        drawChip(g, x + 8, y + H - 38, "Clean", ModConfig.preset == 0, mx, my, a);
        drawChip(g, x + 8, y + H - 24, "Soft", ModConfig.preset == 1, mx, my, a);
        drawChip(g, x + 42, y + H - 24, "Combat", ModConfig.preset == 2, mx, my, a);

        // search
        int sx = x + SIDE + 12, sy = y + 12, sw = W - SIDE - 24;
        GuiDraw.fillRounded(g, sx, sy, sw, 16, 5, Style.alpha(Style.GLASS, a));
        if (searchFocus) g.fill(sx + 2, sy + 15, sx + sw - 2, sy + 16, Style.alpha(Style.ACCENT, a));
        String hint = search.isEmpty() && !searchFocus ? "Поиск..." : search + (searchFocus && (System.currentTimeMillis() / 400) % 2 == 0 ? "_" : "");
        drawSearchText(g, hint, search, sx + 7, sy + 4, a);

        // rows
        int listY = sy + 24;
        int listH = H - 70;
        int max = listH / ROW;
        int maxScroll = Math.max(0, view.size() - max);
        if (scroll > maxScroll) scroll = maxScroll;

        for (int i = 0; i < max; i++) {
            int idx = i + scroll;
            if (idx >= view.size()) break;
            Row r = view.get(idx);
            int ry = listY + i * ROW;
            boolean hov = mx >= x + SIDE + 8 && mx <= x + W - 10 && my >= ry && my < ry + ROW;
            if (hov) g.fill(x + SIDE + 8, ry, x + W - 10, ry + ROW - 1, Style.alpha(Style.ROW_HOV, a));
            // hover accent
            if (hov) g.fill(x + SIDE + 8, ry + 2, x + SIDE + 10, ry + ROW - 3, Style.alpha(Style.ACCENT, a));

            String label = r.name;
            if (!search.isEmpty()) {
                // simple: whole label accent if match
                g.drawText(textRenderer, label, x + SIDE + 16, ry + 5, Style.alpha(Style.ACCENT, a), false);
            } else {
                g.drawText(textRenderer, label, x + SIDE + 16, ry + 5, Style.alpha(Style.TEXT, a), false);
            }

            float k = idx < knob.length ? knob[idx] : (r.get.get() ? 1f : 0f);
            int pw = 28, ph = 14;
            int px = x + W - 18 - pw;
            int py = ry + 2;
            GuiDraw.toggle(g, px, py, pw, ph, k,
                    Style.alpha(Style.ACCENT, a),
                    Style.alpha(Style.TRACK_OFF, a),
                    Style.alpha(Style.KNOB, a));
        }

        // footer
        GuiDraw.fillRounded(g, x + SIDE + 12, y + H - 22, 100, 14, 4, Style.alpha(Style.ACCENT_DIM, a));
        g.drawText(textRenderer, "Переместить HUD", x + SIDE + 20, y + H - 19, Style.alpha(Style.TEXT, a), false);
        g.drawText(textRenderer, "RShift закрыть", x + W - 88, y + H - 19, Style.alpha(Style.TEXT_DIM, a), false);

        super.render(g, mx, my, delta);
    }

    private void drawSearchText(DrawContext g, String shown, String q, int x, int y, float a) {
        g.drawText(textRenderer, shown, x, y, Style.alpha(q.isEmpty() ? Style.TEXT_DIM : Style.TEXT, a), false);
    }

    private void drawSideBtn(DrawContext g, int x, int y, String t, boolean on, int mx, int my, float a) {
        boolean hov = mx >= x && mx <= x + SIDE - 16 && my >= y && my <= y + 14;
        if (on || hov) GuiDraw.fillRounded(g, x, y, SIDE - 16, 14, 4, Style.alpha(on ? Style.ACCENT_DIM : Style.ROW_HOV, a));
        if (on) g.fill(x, y + 2, x + 2, y + 12, Style.alpha(Style.ACCENT, a));
        g.drawText(textRenderer, t, x + 8, y + 3, Style.alpha(on ? Style.TEXT : Style.TEXT_DIM, a), false);
    }

    private void drawChip(DrawContext g, int x, int y, String t, boolean on, int mx, int my, float a) {
        int w = textRenderer.getWidth(t) + 8;
        GuiDraw.fillRounded(g, x, y, w, 11, 3, Style.alpha(on ? Style.ACCENT_DIM : Style.GLASS, a));
        g.drawText(textRenderer, t, x + 4, y + 2, Style.alpha(on ? Style.TEXT : Style.TEXT_DIM, a), false);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();
        int x = width / 2 - W / 2, y = height / 2 - H / 2;

        // side cats
        if (mx >= x + 8 && mx <= x + SIDE - 8) {
            if (my >= y + 36 && my <= y + 50) { cat = Cat.VISUALS; search = ""; filter(); clickSound(); return true; }
            if (my >= y + 54 && my <= y + 68) { cat = Cat.HUD; search = ""; filter(); clickSound(); return true; }
            if (my >= y + 72 && my <= y + 86) { cat = Cat.UTILS; search = ""; filter(); clickSound(); return true; }
        }
        // presets
        if (mx >= x + 8 && mx <= x + 40 && my >= y + H - 38 && my <= y + H - 27) { ModConfig.applyPreset(0); filter(); clickSound(); return true; }
        if (mx >= x + 8 && mx <= x + 36 && my >= y + H - 24 && my <= y + H - 13) { ModConfig.applyPreset(1); filter(); clickSound(); return true; }
        if (mx >= x + 42 && mx <= x + 80 && my >= y + H - 24 && my <= y + H - 13) { ModConfig.applyPreset(2); filter(); clickSound(); return true; }

        int sx = x + SIDE + 12, sy = y + 12, sw = W - SIDE - 24;
        searchFocus = mx >= sx && mx <= sx + sw && my >= sy && my <= sy + 16;

        if (mx >= x + SIDE + 12 && mx <= x + SIDE + 112 && my >= y + H - 22 && my <= y + H - 8) {
            if (client != null) client.setScreen(new LayoutEditScreen(this, targetHUD, potionsRenderer, watermarkRenderer, inventoryHud));
            clickSound();
            return true;
        }

        int listY = sy + 24;
        int max = (H - 70) / ROW;
        for (int i = 0; i < max; i++) {
            int idx = i + scroll;
            if (idx >= view.size()) break;
            int ry = listY + i * ROW;
            if (mx >= x + SIDE + 8 && mx <= x + W - 10 && my >= ry && my < ry + ROW) {
                Row r = view.get(idx);
                r.set.accept(!r.get.get());
                ModConfig.save();
                clickSound();
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = Math.max(0, scroll - (int) Math.signum(v));
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        if (searchFocus && key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1);
            filter();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        int cp = input.codepoint();
        char c = cp > 0 && cp < 0x10000 ? (char) cp : 0;
        if (searchFocus && c >= 32 && search.length() < 28) {
            search += c;
            filter();
            return true;
        }
        return super.charTyped(input);
    }

    @Override
    public void close() {
        ModConfig.save();
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static class Row {
        final Cat cat;
        final String name;
        final String[] keys;
        final Supplier<Boolean> get;
        final Consumer<Boolean> set;
        Row(Cat cat, String name, String[] keys, Supplier<Boolean> get, Consumer<Boolean> set) {
            this.cat = cat; this.name = name; this.keys = keys; this.get = get; this.set = set;
        }
        boolean matches(String q) {
            if (name.toLowerCase(Locale.ROOT).contains(q)) return true;
            for (String k : keys) if (k.contains(q)) return true;
            return false;
        }
    }
}
