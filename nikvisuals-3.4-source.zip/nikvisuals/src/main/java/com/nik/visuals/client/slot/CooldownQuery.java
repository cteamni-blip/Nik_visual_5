package com.nik.visuals.client.slot;

import com.nik.visuals.client.mixin.CooldownInstanceAccessor;
import com.nik.visuals.client.mixin.ItemCooldownsAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.Map;

@Environment(EnvType.CLIENT)
public final class CooldownQuery {
    private CooldownQuery() {}

    /** Returns remaining seconds (ceil), or -1 if none / unknown. */
    public static int remainingSeconds(ClientPlayerEntity player, ItemStack stack, float partial) {
        if (player == null || stack == null || stack.isEmpty()) return -1;
        try {
            ItemCooldownManager mgr = player.getItemCooldownManager();
            float progress = mgr.getCooldownProgress(stack, partial);
            if (progress <= 0.001f) return -1;

            // Try exact ticks via accessors
            if (mgr instanceof ItemCooldownsAccessor acc) {
                Map<Item, ?> map = acc.getCooldowns();
                int tick = acc.getTick();
                Object entry = map.get(stack.getItem());
                if (entry instanceof CooldownInstanceAccessor e) {
                    int end = e.getEndTick();
                    int remTicks = Math.max(0, end - tick);
                    int sec = (int) Math.ceil(remTicks / 20.0);
                    return sec < 1 ? -1 : sec;
                }
            }
            // fallback progress * 60 ticks
            int sec = (int) Math.ceil(progress * 3.0);
            return sec < 1 ? -1 : sec;
        } catch (Throwable t) {
            return -1;
        }
    }

    public static float[] query(ClientPlayerEntity player, ItemStack stack, float partial) {
        int sec = remainingSeconds(player, stack, partial);
        if (sec < 0) return null;
        float progress = player.getItemCooldownManager().getCooldownProgress(stack, partial);
        return new float[]{progress, sec};
    }
}
