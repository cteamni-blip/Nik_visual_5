package com.nik.visuals.client.render;

import net.minecraft.client.gui.DrawContext;

public final class GuiDraw {
    private GuiDraw() {}

    public static void fillRounded(DrawContext g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            g.fill(x, y, x + w, y + h, color);
            return;
        }
        g.fill(x + r, y, x + w - r, y + h, color);
        g.fill(x, y + r, x + w, y + h - r, color);
        // softer corners
        g.fill(x + 1, y + 1, x + r, y + r, color);
        g.fill(x + w - r, y + 1, x + w - 1, y + r, color);
        g.fill(x + 1, y + h - r, x + r, y + h - 1, color);
        g.fill(x + w - r, y + h - r, x + w - 1, y + h - 1, color);
        // extra round feel
        if (r >= 4) {
            g.fill(x + 2, y, x + r, y + 1, color);
            g.fill(x + w - r, y, x + w - 2, y + 1, color);
            g.fill(x + 2, y + h - 1, x + r, y + h, color);
            g.fill(x + w - r, y + h - 1, x + w - 2, y + h, color);
        }
    }

    public static void glassPanel(DrawContext g, int x, int y, int w, int h, int r, int fill, int border) {
        fillRounded(g, x - 1, y - 1, w + 2, h + 2, r + 1, border);
        fillRounded(g, x, y, w, h, r, fill);
        int sheen = (0x22 << 24) | 0xFFFFFF;
        g.fill(x + r, y + 1, x + w - r, y + 2, sheen);
    }

    public static void hpBar(DrawContext g, int x, int y, int w, int h, float pct, int fill, int back) {
        pct = Math.max(0f, Math.min(1f, pct));
        fillRounded(g, x, y, w, h, Math.max(2, h / 2), back);
        int fw = Math.max(h, (int) (w * pct));
        if (pct > 0.01f) fillRounded(g, x, y, fw, h, Math.max(2, h / 2), fill);
    }

    public static void fillSoftCircle(DrawContext g, int cx, int cy, int radius, int color) {
        if (radius <= 0) return;
        for (int dy = -radius; dy <= radius; dy++) {
            int span = (int) Math.sqrt(radius * radius - dy * dy);
            g.fill(cx - span, cy + dy, cx + span + 1, cy + dy + 1, color);
        }
    }

    /** Extra-round toggle track + knob */
    public static void toggle(DrawContext g, int x, int y, int w, int h, float on, int onColor, int offColor, int knob) {
        int track = lerpColor(offColor, onColor, on);
        fillRounded(g, x, y, w, h, h / 2, track);
        int kw = h - 2;
        int kx = x + 1 + (int) ((w - kw - 2) * on);
        fillRounded(g, kx, y + 1, kw, kw, kw / 2, knob);
    }

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return (((int) (aa + (ba - aa) * t)) << 24)
             | (((int) (ar + (br - ar) * t)) << 16)
             | (((int) (ag + (bg - ag) * t)) << 8)
             |  ((int) (ab + (bb - ab) * t));
    }
}
