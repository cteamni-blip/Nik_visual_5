package com.nik.visuals.client.mixin;

import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.Item;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;

@Mixin(ItemCooldownManager.class)
public interface ItemCooldownsAccessor {
    @Accessor("entries")
    Map<Item, ?> getCooldowns();

    @Accessor("tick")
    int getTick();
}
