package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

@Environment(EnvType.CLIENT)
public class ArmorHudRenderer {
    private static final EquipmentSlot[] SLOTS = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private long lastWarnSoundMs;

    public void render(DrawContext g, float pt) {
        if (!ModConfig.armorHud) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options.hudHidden || mc.currentScreen != null) {
            return;
        }
        int baseX = mc.getWindow().getScaledWidth() / 2 + 95;
        int baseY = mc.getWindow().getScaledHeight() - 20;
        boolean anyLow = false;
        int idx = 0;
        long now = System.currentTimeMillis();
        boolean blink = now / 400L % 2L == 0L;
        for (EquipmentSlot slot : SLOTS) {
            ItemStack stack = p.getEquippedStack(slot);
            if (stack.isEmpty()) {
                ++idx;
                continue;
            }
            int x = baseX;
            int y = baseY - (3 - idx) * 16;
            g.fill(x - 1, y - 1, x + 18, y + 15, -2013265920);
            g.drawItem(stack, x, y - 1);
            g.drawStackOverlay(mc.textRenderer, stack, x, y - 1);
            if (stack.isDamageable()) {
                float ratio;
                int max = stack.getMaxDamage();
                int left = Math.max(0, max - stack.getDamage());
                float f = ratio = max > 0 ? (float)left / (float)max : 1.0f;
                int color = ratio > 0.5f ? -11141291 : (ratio > 0.25f ? -171 : -43691);
                String num = String.valueOf(left);
                g.drawText(mc.textRenderer, num, x + 18, y + 3, color, true);
                if (ModConfig.armorWarn && left <= 100) {
                    anyLow = true;
                    if (blink) {
                        int bx = x + 18 + mc.textRenderer.getWidth(num) + 3;
                        g.fill(bx - 1, y, bx + 7, y + 11, -872415232);
                        g.drawText(mc.textRenderer, "!", bx, y + 1, -52429, true);
                    }
                }
            }
            ++idx;
        }
        if (ModConfig.armorWarn && anyLow && now - this.lastWarnSoundMs > 3500L) {
            this.lastWarnSoundMs = now;
            try {
                try { mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), 0.7f, 0.15f)); } catch (Throwable ignored) {}
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }
}

