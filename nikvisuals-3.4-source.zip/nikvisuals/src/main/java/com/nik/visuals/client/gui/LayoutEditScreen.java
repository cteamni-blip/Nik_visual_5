package com.nik.visuals.client.gui;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.InventoryHudRenderer;
import com.nik.visuals.client.render.PotionsRenderer;
import com.nik.visuals.client.render.TargetHUD;
import com.nik.visuals.client.render.WatermarkRenderer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public class LayoutEditScreen
extends Screen {
    private final Screen parent;
    private final TargetHUD targetHUD;
    private final PotionsRenderer potionsRenderer;
    private final WatermarkRenderer watermarkRenderer;
    private final InventoryHudRenderer inventoryHud;
    private Mode mode = Mode.NONE;
    private int offsetX;
    private int offsetY;
    private final float snapTX;
    private final float snapTY;
    private final float snapPX;
    private final float snapPY;
    private final float snapWX;
    private final float snapWY;
    private final float snapIX;
    private final float snapIY;
    private final float snapTS;
    private final float snapPS;
    private final float snapIS;
    private static final int HANDLE = 8;

    public LayoutEditScreen(Screen parent, TargetHUD targetHUD, PotionsRenderer potionsRenderer, WatermarkRenderer watermarkRenderer, InventoryHudRenderer inventoryHud) {
        super((Text)Text.literal((String)"Layout"));
        this.parent = parent;
        this.targetHUD = targetHUD;
        this.potionsRenderer = potionsRenderer;
        this.watermarkRenderer = watermarkRenderer;
        this.inventoryHud = inventoryHud;
        this.snapTX = ModConfig.targetHudX;
        this.snapTY = ModConfig.targetHudY;
        this.snapPX = ModConfig.potionsX;
        this.snapPY = ModConfig.potionsY;
        this.snapWX = ModConfig.watermarkX;
        this.snapWY = ModConfig.watermarkY;
        this.snapIX = ModConfig.inventoryHudX;
        this.snapIY = ModConfig.inventoryHudY;
        this.snapTS = ModConfig.targetHudScale;
        this.snapPS = ModConfig.potionsScale;
        this.snapIS = ModConfig.inventoryHudScale;
    }

    protected void init() {
        ModConfig.layoutEdit = true;
    }

    public void render(DrawContext g, int mx, int my, float delta) {
        g.fill(0, 0, this.width, this.height, 0x44000000);
        this.targetHUD.render(g, delta);
        this.potionsRenderer.render(g, delta);
        this.watermarkRenderer.render(g, delta);
        this.inventoryHud.render(g, delta);
        this.drawHandle(g, this.targetHUD.getLastX() + this.targetHUD.scaledW(), this.targetHUD.getLastY() + this.targetHUD.scaledH());
        this.drawHandle(g, this.potionsRenderer.getLastX() + Math.max(40, this.potionsRenderer.getLastW()), this.potionsRenderer.getLastY() + Math.max(16, this.potionsRenderer.getLastH()));
        this.drawHandle(g, this.inventoryHud.getLastX() + this.inventoryHud.getLastW(), this.inventoryHud.getLastY() + this.inventoryHud.getLastH());
        g.drawCenteredTextWithShadow(this.textRenderer, "\u00a7d\u0420\u0435\u0436\u0438\u043c \u043f\u0435\u0440\u0435\u043c\u0435\u0449\u0435\u043d\u0438\u044f", this.width / 2, 12, -2043649);
        int bw = 90;
        int bh = 18;
        int gap = 12;
        int total = bw * 2 + gap;
        int bx = (this.width - total) / 2;
        int by = this.height - 36;
        g.fill(bx, by, bx + bw, by + bh, -14001622);
        g.drawCenteredTextWithShadow(this.textRenderer, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c", bx + bw / 2, by + 5, -1);
        g.fill(bx + bw + gap, by, bx + bw + gap + bw, by + bh, -10868182);
        g.drawCenteredTextWithShadow(this.textRenderer, "\u041e\u0442\u043c\u0435\u043d\u0438\u0442\u044c", bx + bw + gap + bw / 2, by + 5, -1);
        super.render(g, mx, my, delta);
    }

    private void drawHandle(DrawContext g, int hx, int hy) {
        g.fill(hx - 4, hy - 4, hx + 4, hy + 4, -4487428);
    }

    private boolean near(double mx, double my, int hx, int hy) {
        return Math.abs(mx - (double)hx) <= 8.0 && Math.abs(my - (double)hy) <= 8.0;
    }

    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();
        int button = 0;
        int bw = 90;
        int bh = 18;
        int gap = 12;
        int total = bw * 2 + gap;
        int bx = (this.width - total) / 2;
        int by = this.height - 36;
        if (button == 0) {
            int ih;
            int ph;
            int th;
            if (mx >= (double)bx && mx <= (double)(bx + bw) && my >= (double)by && my <= (double)(by + bh)) {
                this.save();
                return true;
            }
            if (mx >= (double)(bx + bw + gap) && mx <= (double)(bx + bw + gap + bw) && my >= (double)by && my <= (double)(by + bh)) {
                this.cancel();
                return true;
            }
            int tx = this.targetHUD.getLastX();
            int ty = this.targetHUD.getLastY();
            int tw = this.targetHUD.scaledW();
            if (this.near(mx, my, tx + tw, ty + (th = this.targetHUD.scaledH()))) {
                this.mode = Mode.RESIZE_TARGET;
                return true;
            }
            int px = this.potionsRenderer.getLastX();
            int py = this.potionsRenderer.getLastY();
            int pw = Math.max(40, this.potionsRenderer.getLastW());
            if (this.near(mx, my, px + pw, py + (ph = Math.max(16, this.potionsRenderer.getLastH())))) {
                this.mode = Mode.RESIZE_POTIONS;
                return true;
            }
            int ix = this.inventoryHud.getLastX();
            int iy = this.inventoryHud.getLastY();
            int iw = this.inventoryHud.getLastW();
            if (this.near(mx, my, ix + iw, iy + (ih = this.inventoryHud.getLastH()))) {
                this.mode = Mode.RESIZE_INV;
                return true;
            }
            if (mx >= (double)tx && mx <= (double)(tx + tw) && my >= (double)ty && my <= (double)(ty + th)) {
                this.mode = Mode.MOVE_TARGET;
                this.offsetX = (int)mx - tx;
                this.offsetY = (int)my - ty;
                return true;
            }
            if (mx >= (double)px && mx <= (double)(px + pw) && my >= (double)py && my <= (double)(py + ph)) {
                this.mode = Mode.MOVE_POTIONS;
                this.offsetX = (int)mx - px;
                this.offsetY = (int)my - py;
                return true;
            }
            if (mx >= (double)ix && mx <= (double)(ix + iw) && my >= (double)iy && my <= (double)(iy + ih)) {
                this.mode = Mode.MOVE_INV;
                this.offsetX = (int)mx - ix;
                this.offsetY = (int)my - iy;
                return true;
            }
            int wx = this.watermarkRenderer.getLastX();
            int wy = this.watermarkRenderer.getLastY();
            if (mx >= (double)wx && mx <= (double)(wx + 176) && my >= (double)wy && my <= (double)(wy + 20)) {
                this.mode = Mode.MOVE_WATERMARK;
                this.offsetX = (int)mx - wx;
                this.offsetY = (int)my - wy;
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    public boolean mouseDragged(Click click, double dx, double dy) {
        double mx = click.x();
        double my = click.y();
        int button = 0;
        if (button != 0 || this.mode == Mode.NONE || this.width <= 0) {
            return super.mouseDragged(click, dx, dy);
        }
        if (this.mode == Mode.RESIZE_TARGET) {
            int tx = this.targetHUD.getLastX();
            int ty = this.targetHUD.getLastY();
            double base = Math.max(40.0, Math.hypot(96.0, 30.0));
            ModConfig.targetHudScale = (float)Math.max(0.5, Math.min(2.0, Math.hypot(Math.max(20.0, mx - (double)tx), Math.max(12.0, my - (double)ty)) / base));
            return true;
        }
        if (this.mode == Mode.RESIZE_POTIONS) {
            int px = this.potionsRenderer.getLastX();
            int py = this.potionsRenderer.getLastY();
            ModConfig.potionsScale = (float)Math.max(0.5, Math.min(2.0, Math.hypot(Math.max(20.0, mx - (double)px), Math.max(12.0, my - (double)py)) / 90.0));
            return true;
        }
        if (this.mode == Mode.RESIZE_INV) {
            int ix = this.inventoryHud.getLastX();
            int iy = this.inventoryHud.getLastY();
            double base = Math.hypot(162.0, 54.0);
            ModConfig.inventoryHudScale = (float)Math.max(0.5, Math.min(1.8, Math.hypot(Math.max(20.0, mx - (double)ix), Math.max(12.0, my - (double)iy)) / base));
            return true;
        }
        if (this.mode == Mode.MOVE_WATERMARK) {
            ModConfig.watermarkX = Math.max(0.05f, Math.min(0.95f, (float)mx / (float)this.width));
            ModConfig.watermarkY = Math.max(0.0f, Math.min(0.95f, (float)(my - (double)this.offsetY) / (float)this.height));
            return true;
        }
        float nx = Math.max(0.0f, Math.min(0.95f, (float)(mx - (double)this.offsetX) / (float)this.width));
        float ny = Math.max(0.0f, Math.min(0.95f, (float)(my - (double)this.offsetY) / (float)this.height));
        if (this.mode == Mode.MOVE_TARGET) {
            ModConfig.targetHudX = nx;
            ModConfig.targetHudY = ny;
        } else if (this.mode == Mode.MOVE_POTIONS) {
            ModConfig.potionsX = nx;
            ModConfig.potionsY = ny;
        } else if (this.mode == Mode.MOVE_INV) {
            ModConfig.inventoryHudX = nx;
            ModConfig.inventoryHudY = ny;
        }
        return true;
    }

    public boolean mouseReleased(Click click) {
        double mx = click.x();
        double my = click.y();
        int button = 0;
        this.mode = Mode.NONE;
        return super.mouseReleased(click);
    }

    private void save() {
        ModConfig.layoutEdit = false;
        ModConfig.save();
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }

    private void cancel() {
        ModConfig.targetHudX = this.snapTX;
        ModConfig.targetHudY = this.snapTY;
        ModConfig.potionsX = this.snapPX;
        ModConfig.potionsY = this.snapPY;
        ModConfig.watermarkX = this.snapWX;
        ModConfig.watermarkY = this.snapWY;
        ModConfig.inventoryHudX = this.snapIX;
        ModConfig.inventoryHudY = this.snapIY;
        ModConfig.targetHudScale = this.snapTS;
        ModConfig.potionsScale = this.snapPS;
        ModConfig.inventoryHudScale = this.snapIS;
        ModConfig.layoutEdit = false;
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }

    public void close() {
        this.cancel();
    }

    public boolean shouldPause() {
        return false;
    }

    @Environment(EnvType.CLIENT)
    private static enum Mode {
        NONE,
        MOVE_TARGET,
        MOVE_POTIONS,
        MOVE_WATERMARK,
        MOVE_INV,
        RESIZE_TARGET,
        RESIZE_POTIONS,
        RESIZE_INV;

    }
}

