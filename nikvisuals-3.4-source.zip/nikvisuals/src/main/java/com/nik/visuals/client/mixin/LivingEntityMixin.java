package com.nik.visuals.client.mixin;

import com.nik.visuals.client.slot.HealCooldowns;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Shadow
    public abstract ItemStack getActiveItem();

    @Inject(method = "consumeItem", at = @At("HEAD"), require = 0)
    private void nik$onFinishUse(CallbackInfo ci) {
        try {
            if (MinecraftClient.getInstance().player != (Object) this) return;
            HealCooldowns.onFinish(this.getActiveItem());
        } catch (Throwable ignored) {}
    }
}
