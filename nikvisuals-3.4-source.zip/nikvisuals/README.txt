Nik Visuals 3.4

- Potion icons aligned 16x16
- Target head: skin + hat layer, PlayerListEntry fallback
- Trajectory: depth test off + translucent lines (see through blocks)
- Cooldown seconds via mixin accessors when possible
- Swap: unique names only; single clickSlot SWAP to offhand (no hotbar packets)
- Short cooldown 350ms; freeze while holding key
- Menu palette polish
